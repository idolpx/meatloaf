self.addEventListener('install', event => {
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', event => {
  // Only intercept same-origin requests. Cross-origin fetches (external APIs,
  // CDNs) must go straight to the network — routing them through the SW causes
  // the browser to see duplicate CORS headers and reject the response.
  if (new URL(event.request.url).origin !== self.location.origin) return;

  event.respondWith(
    caches.match(event.request).then(response => {
      return response || fetch(event.request);
    })
  );
});
